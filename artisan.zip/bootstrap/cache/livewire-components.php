<?php return array (
  'admin.admin-dashboard-component' => 'App\\Http\\Livewire\\Admin\\AdminDashboardComponent',
  'cart-component' => 'App\\Http\\Livewire\\CartComponent',
  'checkout-component' => 'App\\Http\\Livewire\\CheckoutComponent',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'shop-component' => 'App\\Http\\Livewire\\ShopComponent',
  'user.user-dashboard-component' => 'App\\Http\\Livewire\\User\\UserDashboardComponent',
);