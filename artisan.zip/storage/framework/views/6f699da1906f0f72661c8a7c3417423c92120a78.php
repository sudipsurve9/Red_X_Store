<div>
<h1>User dashboard </h1></div>
<?php /**PATH C:\xampp\htdocs\Red_X_Store\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>