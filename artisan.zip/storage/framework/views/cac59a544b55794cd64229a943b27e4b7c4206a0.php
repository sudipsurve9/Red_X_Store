<div>
    <h1>admin dashboard</h1>
</div><?php /**PATH C:\xampp\htdocs\Red_X_Store\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>