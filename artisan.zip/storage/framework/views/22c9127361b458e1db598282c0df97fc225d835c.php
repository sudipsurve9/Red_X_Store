<div>
    Checkout Page
</div>
<?php /**PATH C:\xampp\htdocs\Red_X_Store\resources\views\livewire\checkout-component.blade.php ENDPATH**/ ?>