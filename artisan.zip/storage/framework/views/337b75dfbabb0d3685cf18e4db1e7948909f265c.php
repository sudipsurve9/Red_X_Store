<div>
cart Page
</div>
<?php /**PATH C:\xampp\htdocs\Red_X_Store\resources\views\livewire\cart-component.blade.php ENDPATH**/ ?>